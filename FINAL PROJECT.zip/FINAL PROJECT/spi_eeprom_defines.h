                            /* spi_eeprom_defines.h */
#ifndef __SPI_EEPROM_DEFINES_H__
#define __SPI_EEPROM_DEFINES_H__

//Instruction Set 
#define READ   0x03 
#define WRITE  0x02 
#define WRDI   0x04 
#define WREN   0x06 
    
#endif
